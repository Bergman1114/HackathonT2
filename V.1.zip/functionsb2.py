import connection as c 
import mysql.connector
import os, datetime
from os import system
from datetime import *

system('cls')

def LoginPage():
    print('''
    THESE ARE THE OPTIONS:
    1. Exsiting User
    2. New User
    3. Exit
    ''')
    choice = int(input('Select an option >> '))
    if( choice == 1 ):
        LoginEC() #login
    elif( choice == 2 ):
        NewCusAct()  #newuser 
    elif( choice == 3 ):
        print("Now Stealing your DATA...")
        sleep(2)
        exit()
    else:
        print("Choose a valid option")
        LoginPage('')


#####################################

# def LoginEC():
#     conn = c.returnConnection()
#     while True:
#         EUN = input("Enter The Username: ")
#         PWD = input("Enter The Password: ")
#         cursor = conn.cursor()
#         select_user = ("SELECT * FROM useract WHERE Username = ? AND Password = ?")
#         cursor.execute("SELECT user_password FROM useract WHERE username=%s", '{username}')
#         row = cursor.fetchone()
#         cursor.close()
#         conn.close()
#         break

# LoginPage()

######################################

# def LoginEC():
#     EUN = input("Enter The Username: ")
#     PWD = input("Enter The Password: ")
#     if( PWD == user.password):
#         print("Access, you are logged in and fully authenticated : " + user.name)
#     else:
#         print("The username and password you used does not match our records")
#         login(user)
#     LoginPage('')

# LoginPage('')


########################################


def LoginEC():
    user = input('Please enter your username : ')
    passwd = input('Please enter your password : ')

    path = './HackathonT2/logs.txt'
    username = 'Kite' #['Kite', 'Shweta']
    password = 'pass1' #['pass1', 'pass2']

    def printAccessOrNot(message):
        if (message == 'Access'):
            with open(path, 'a') as log:
                log.write(f'\nUser {user} tried to log in on {datetime.now()} - Result: {message}')
                log.close()
        else:
            with open(path, 'a') as log:
                log.write(f'\nUser {user} tried to log in on {datetime.now()} - Result: {message}')
                log.close()
    if(user == username and passwd == password):
        print(f'Hello {user}, you are logged in and fully authenticated')
        printAccessOrNot('Access')
    else:
        print('The username and password you used does not match our records')
        printAccessOrNot('Denied')

def NewCusAct():
    for u in range(userdata):
        userdata = {}
        print()
        print(f'ENTER TEXT HERE {counter}: ')
        nusername = input('Enter your user name >> ')
        userdata['UserName'] = nusername
        npassword = input('Enter your password >> ')
        userdata['Password'] = npassword
        Email = int(input('Enter your Email >> '))
        userdata['Email'] = Email
        userinfo.append(userdata)
        counter += 1
        print()

LoginPage()