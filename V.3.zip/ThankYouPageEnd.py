import os
from os import system 

system ('clear')

# Thank You Page - Ahmad
print(f'\u001b[35m*********************************************************************************\u001b[33m')
print(f'                           Thank You For Your Business                           ')
print(f'                      Your Order Was Completed Successfully                      ')
print(f'\u001b[35m*********************************************************************************\u001b[33m')
print()
print(f'\u001b[35m*********************************************************************************\u001b[33m')
print(f'        An email receipt including the details about your order has been,        ')
print(f'      sent to your email address provided. Please keep it for your records.      ')
print(f'\u001b[35m*********************************************************************************\u001b[33m')
print()
print(f'\u001b[35m*********************************************************************************\u001b[33m')
print(f'You can visit the "My Account Page" at any time to check the satus of your order!')
print(f'\u001b[35m*********************************************************************************\u001b[33m')
print(f'-----------------  Thank You Again! We hope to see again soon!  -----------------')
print(f'\u001b[35m*********************************************************************************\u001b[33m')