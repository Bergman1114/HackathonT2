s c 
# import mysql.connec